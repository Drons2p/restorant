<?php $__env->startSection('content'); ?>

        <div class="container">
            <div class="content">

        <?php foreach($orders as $order): ?>
        
         <?php echo e($order->user->name); ?> - <?php echo e($order->created_at); ?> <br />
         
            <?php foreach($order->dish as $dish): ?>
         
         <?php echo e($dish->name); ?> <br />
         
          <?php endforeach; ?>
          
          <br /><br />
          
      <?php endforeach; ?>

            </div>
        </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>