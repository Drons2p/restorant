<?php $__env->startSection('content'); ?>


<div class="container-fluid">
   <div class="row">      
          <div class="col-lg-8"> 
          

                <div class="title">Меню</div>
                
          <?php if (app('Illuminate\Contracts\Auth\Access\Gate')->check('create')): ?> <!-- проверяем права -->
        
                          <!-- Button trigger modal -->
                                    <button class="btn btn-primary" data-toggle="modal" data-target="#catModal">
                                           Добавить категорию
                                          </button>
                                          
                                          <br /><br /><br />
                                          
                                              <!-- Modal -->
                                    <div class="modal fade" id="catModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                                      <div class="modal-dialog">
                                        <div class="modal-content">
                                          <div class="modal-header">
                                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                                            <h4 class="modal-title" id="catModalLabel">Добавление категории</h4>
                                          </div>
                                          <div class="modal-body">
                                            
                                          <form class="form-horizontal" role="form" method="POST" action="/сategory/create">              
                                                    <input type="text" class="form-control" name="name" value="">                      
                                                    <input type="text" class="form-control" name="description" value="">          
                
                                                    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>"/>
                                    
                                            
                                          </div>
                                          <div class="modal-footer">
                                            <button type="button" class="btn btn-default" data-dismiss="modal">Закрыть</button>
                                          
                                                     <button type="submit" class="btn btn-primary">
                                                        <i class="fa fa-btn fa-sign-in"></i>Добавить
                                                    </button>
                                             
                                        </form> 
                                        
                                        </div>
                                        </div>
                                      </div>
                                    </div>
                                                                           

            
    <?php endif; ?>
    
                  
    <?php foreach($categories as $category): ?>
 
  <div class="panel panel-default">
  <div class="panel-heading">
    <h3 class="panel-title"><?php echo e($category->name); ?></h3>
  </div>
  <div class="panel-body">  
  
  
<div class="container-fluid">
   <div class="row">      
          <div class="col-lg-6"> 
          <?php echo e($category->description); ?>


       </div>     
          <div class="col-lg-3"> 
          <?php if (app('Illuminate\Contracts\Auth\Access\Gate')->check('create')): ?> <!-- проверяем права -->

                                         <!-- Button trigger modal -->
                                    <button class="btn btn-primary" data-toggle="modal" data-target="#catModal<?php echo e($category->id); ?>">
                                           Редактировать категорию
                                          </button>      
                                                                         
                                              <!-- Modal -->
                                    <div class="modal fade" id="catModal<?php echo e($category->id); ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                                      <div class="modal-dialog">
                                        <div class="modal-content">
                                          <div class="modal-header">
                                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                                            <h4 class="modal-title" id="catModalLabel">Редактирование категории</h4>
                                          </div>
                                          <div class="modal-body">
                                            
                                          <form class="form-horizontal" role="form" method="POST" action="/сategory/save">            
                                                    <input type="text" class="form-control" name="name" value="<?php echo e($category->name); ?>">                      
                                                    <input type="text" class="form-control" name="description" value="<?php echo e($category->description); ?>">    
                                                    <input type="hidden" name="id" value="<?php echo e($category->id); ?>"/>   
                                                    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>"/>
                                    
                                            
                                          </div>
                                          <div class="modal-footer">
                                            <button type="button" class="btn btn-default" data-dismiss="modal">Закрыть</button>
                                          
                                                     <button type="submit" class="btn btn-primary">
                                                        <i class="fa fa-btn fa-sign-in"></i>Сохринить
                                                    </button>
                                             
                                        </form> 
                                        
                                        </div>
                                        </div>
                                      </div>
                                    </div>
          
          
    <?php endif; ?>
          
       </div>     
          <div class="col-lg-3"> 
                
          <?php if (app('Illuminate\Contracts\Auth\Access\Gate')->check('create')): ?> <!-- проверяем права -->

          
                                                        <!-- Button trigger modal -->
                                    <button class="btn btn-primary" data-toggle="modal" data-target="#dishcreateModal<?php echo e($category->id); ?>">
                                           Добавить блюдо
                                          </button>
                                          
                                          <br />
                                          
                                              <!-- Modal -->
                                    <div class="modal fade" id="dishcreateModal<?php echo e($category->id); ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                                      <div class="modal-dialog">
                                        <div class="modal-content">
                                          <div class="modal-header">
                                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                                            <h4 class="modal-title" id="dishcreateModalLabel">Добавление блюда</h4>
                                          </div>
                                          <div class="modal-body">
                                            
                                          <form class="form-horizontal" role="form" method="POST" action="/dish/create">              
                                                    <input type="text" class="form-control" name="name" value="">                      
                                                    <input type="text" class="form-control" name="description" value="">          
                                                     <input type="hidden" name="category_id" value="<?php echo e($category->id); ?>"/>  
                                                    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>"/>
                                    
                                            
                                          </div>
                                          <div class="modal-footer">
                                            <button type="button" class="btn btn-default" data-dismiss="modal">Закрыть</button>
                                          
                                                     <button type="submit" class="btn btn-primary">
                                                        <i class="fa fa-btn fa-sign-in"></i>Добавить
                                                    </button>
                                             
                                        </form> 
                                        
                                        </div>
                                        </div>
                                      </div>
                                    </div>        
           
    <?php endif; ?>
                 
                                     
       </div>     
    </div>  
</div> 

  <br /><br />
          
              <?php foreach($category->dishes as $dish): ?>
  
<div class="container-fluid">
   <div class="row">      
          <div class="col-lg-2"> 
          
                  <?php echo e($dish->name); ?>  
                                       
       </div>      
          <div class="col-lg-1"> 
          <?php echo e($dish->price); ?>


       </div>     
          <div class="col-lg-4"> 
           
                  <?php echo e($dish->description); ?>

       </div>       
          <div class="col-lg-2"> 
           <button class="btn btn-primary ad-to-ord" data-price="<?php echo e($dish->price); ?>" data-id="<?php echo e($dish->id); ?>" data-name="<?php echo e($dish->name); ?>"> Добавить в заказ </button>
       </div>     
          <div class="col-lg-3"> 
          
          <?php if (app('Illuminate\Contracts\Auth\Access\Gate')->check('create')): ?> <!-- проверяем права -->

                                      <!-- Button trigger modal -->
                                    <button class="btn btn-primary" data-toggle="modal" data-target="#dishModal<?php echo e($dish->id); ?>">
                                           Редактировать блюдо
                                          </button>
                                          
                                          <br />
                                          
                                              <!-- Modal -->
                                    <div class="modal fade" id="dishModal<?php echo e($dish->id); ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                                      <div class="modal-dialog">
                                        <div class="modal-content">
                                          <div class="modal-header">
                                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                                            <h4 class="modal-title" id="dishModalLabel">Редактировать блюдо</h4>
                                          </div>
                                          <div class="modal-body">
                                            
                                          <form class="form-horizontal" role="form" method="POST" action="/dish/create">              
                                                    <input type="text" class="form-control" name="name" value="<?php echo e($dish->name); ?>">                      
                                                    <input type="text" class="form-control" name="description" value="<?php echo e($dish->description); ?>">          
                                                    
                                                    
                                                     <input type="hidden" name="category_id" value="<?php echo e($category->id); ?>"/>  
                                                                                                           
                                                           <select name="category_id"> 
                                                                   
                                                                    <?php foreach($categories as $category_dish): ?>
                                                                   
                                                                       <?php if($category_dish->id == $dish->category_id): ?>
                                                                    <option selected value="<?php echo e($category_dish->id); ?>"> <?php echo e($category_dish->name); ?> </option>
                                                                    
                                                                   <?php else: ?> 
                                                                    <option value="<?php echo e($category_dish->id); ?>"><?php echo e($category_dish->name); ?></option>
                                                                   <?php endif; ?>
                                                                    
                                                                    <?php endforeach; ?>
                                                                  
                                                            </select>
                                                                                                            
                                                    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>" />
                                    
                                            
                                          </div>
                                          <div class="modal-footer">
                                            <button type="button" class="btn btn-default" data-dismiss="modal">Закрыть</button>
                                          
                                                     <button type="submit" class="btn btn-primary">
                                                        <i class="fa fa-btn fa-sign-in"></i>Добавить
                                                    </button>
                                             
                                        </form> 
                                        
                                        </div>
                                        </div>
                                      </div>
                                    </div>
           
         
    <?php endif; ?>         
                                       
       </div>     
    </div>  
</div>     
 
                  
                  <br />
          <?php endforeach; ?>
    <br /><br /><br />
    
  </div>
</div>    

      <?php endforeach; ?>
 
 
              </div>
              
          <div class="col-lg-4"> 
                <div class="title"><?php echo e($title_form); ?></div>
         
                      
             <form id="order-form" class="form" role="form" method="POST" action="/order/create">          
                                      
			 <?php if(Session::has('user_id')): ?>
	         
<div class="container-fluid">
   <div class="row">      
          <div class="col-lg-6"> 
                           <select class="form-control" name="sent"> 
                           
                                <option value="0">Как ченовик</option>
                                <option value="1">Как заказ</option>
                            </select>
                            
          <input type="hidden" name="grup_id" value="<?php echo e($grup_id); ?>"/>
                      
       </div>     

    
          <div class="col-lg-6"> 
          
                             <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>"/>
                                                         <button type="submit" class="btn btn-primary">
                                                        Оотправить
                                                    </button>
                      
       </div>     
    </div>  
</div>      

			<?php endif; ?>
                   
         <?php if($checkbox_form): ?>             
                 <?php echo $checkbox_form; ?>   
          <?php endif; ?>
                       
         <?php if($draft): ?>  
         <input type="hidden" name="id" value="<?php echo e($draft->id); ?>"/>
          <?php endif; ?>
          
                        </form>  
                  
 
        <br />
        
 <div>Всего: <div id="total"></div></div>
        
 
                
                      
              <br />
    
                <div class="title">Группы</div>
                  
    <?php foreach($grups as $grup): ?>
        
        <?php echo e($grup->name); ?> - основатель <?php echo e($grup->founder()->name); ?>

       <?php if(!in_array($grup->id, $Userreqslist)): ?>
           <?php if(in_array($grup->id, $Usergruplist)): ?>
            
          - <a href="/grup/detach/<?php echo e(\Session::get('user_id')); ?>/<?php echo e($grup->id); ?>"> Покинуть</a> 
          - <a href="/grup/order/store/<?php echo e($grup->id); ?>"> Заказ от группы</a> 
                  
              <?php else: ?> 
           <a href="/grup/req/<?php echo e($grup->id); ?>"> - Присоеденится</a>   
                                       
              <?php endif; ?>                  
          <?php endif; ?>
        <br />
        <?php foreach($grup->users as $user): ?>
        
               <?php echo e($user->name); ?> 
               
           <?php if($grup->admin_id == Session::get('user_id')): ?>
               <a href="/grup/detach/<?php echo e($user->id); ?>/<?php echo e($grup->id); ?>">Удалить</a>  
                        
              <?php endif; ?>       
           
        <br />
        
          <?php endforeach; ?>
          <br />
          
      <?php endforeach; ?>
        
        <br /><br /><br />
                
                <div class="title">Запросы</div>
                
        <?php foreach($reqs as $req): ?>
        
          <?php echo e($req->grup->name); ?> - <?php echo e($req->user->name); ?> -  <a href="/grup/accept/ <?php echo e($req->id); ?>">Принять</a> <br /> 
        
          <?php endforeach; ?>
          <br /><br />
              
              </div>
              
   </div>
</div>
                
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>