<?php $__env->startSection('content'); ?>

        <div class="container">
            <div class="content">
                <div class="title">email</div>
                
                  
                  <?php echo e($email); ?><br /> 
                  
            </div>
            </div>
        </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>