@extends('layouts.default')
@section('content')

        <div class="container">
            <div class="content">
            <div class="bs-callout bs-callout-danger">
              <h4>Внимание</h4>
              <p>{{ $msg }}</p>
             
            </div> 
               
            </div>
        </div>
@stop

