<div class="main-con bg-dk-grey" id="footer">

    <div class="copyright-bg">
        <div class="container">

            <div class="cpyright-con pull-right" >
             
            
            </div>
        </div>
    </div>
</div>
</body>
</html>